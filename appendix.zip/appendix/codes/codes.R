library(mice)

setwd("..\\Desktop\\essay process")
trainSet <- openxlsx::read.xlsx(xlsxFile = "random trainset.xlsx")
testSet <- openxlsx::read.xlsx(xlsxFile = "random testset.xlsx")


trainSet <- trainSet[,-1]
testSet <- testSet[,-1]
trainSet <- cbind(trainSet[,7]/trainSet[,8],trainSet)
testSet <- cbind(testSet[,7]/testSet[,8],testSet)
tempData <- mice(trainSet,m=5,meth='pmm')
trainSet <- complete(tempData)

FakeDikarProduct <- function(trainSet){

CoughAndFever <- c()
CoughNoFever <- c()
NoCoughFever <- c()
NoCoughNoFever <- c()
for(i in 1:length(trainSet[,1])){
  if(trainSet[i,"CoughOrNot"]==1 & trainSet[i,"FeverOrNot"]==1){
    CoughAndFever <- rbind(CoughAndFever,1)
  }else{CoughAndFever <- rbind(CoughAndFever,0)}
  if(trainSet[i,"CoughOrNot"]==1 & trainSet[i,"FeverOrNot"]==0){
    CoughNoFever <- rbind(CoughNoFever,1)
  }else{CoughNoFever <- rbind(CoughNoFever,0)}
  if(trainSet[i,"CoughOrNot"]==0 & trainSet[i,"FeverOrNot"]==1){
    NoCoughFever <- rbind(NoCoughFever,1)
  }else{NoCoughFever <- rbind(NoCoughFever,0)}
  if(trainSet[i,"CoughOrNot"]==0 & trainSet[i,"FeverOrNot"]==0){
    NoCoughNoFever <- rbind(NoCoughNoFever,1)
  }else{NoCoughNoFever <- rbind(NoCoughNoFever,0)}
}
DikarEncoder <- cbind(CoughAndFever,NoCoughNoFever,NoCoughFever,CoughNoFever)
colnames(DikarEncoder) <- c("CoughAndFever","NoCoughNoFever",
                            "NoCoughFever","CoughNoFever")
return(DikarEncoder)
}
DikarEncoder <- FakeDikarProduct(trainSet)
trainSet <- cbind(DikarEncoder,trainSet)
colnames(trainSet)[5] <- "Fat"

DikarEncoder <- FakeDikarProduct(testSet)
testSet <- cbind(DikarEncoder,testSet)
colnames(testSet)[5] <- "Fat"

write.csv(trainSet,file = "train.csv",row.names = F)
write.csv(testSet,file = "test.csv",row.names = F)
